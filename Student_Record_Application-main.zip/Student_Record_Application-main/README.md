# Student_Record_Application
Performs CRUD queries over student records of a particular institution.
It is a Java based Application, staged on Swing for graphics and integrated with JDBC for CRUD queries on mySQL. 
This will run on a local client's device. To set up the application you should change the credentials of the mySQL client and then the application will run smoothly

Screen Shots

![image](https://github.com/AmolChi/Student_Record_Application/assets/75240926/bef0f3c2-108f-4bcd-8819-f020572c3345)

![image](https://github.com/AmolChi/Student_Record_Application/assets/75240926/e96a953c-b7ad-48ed-8923-bae6f0e6109e)

![image](https://github.com/AmolChi/Student_Record_Application/assets/75240926/fb9f395c-999d-4757-8e73-fc1b25740534)

![image](https://github.com/AmolChi/Student_Record_Application/assets/75240926/5b14fb2e-7197-4a4a-b165-24e21e5ef5c1)

![image](https://github.com/AmolChi/Student_Record_Application/assets/75240926/31182ec4-c442-4fc2-98a6-c2d43657ff25)

